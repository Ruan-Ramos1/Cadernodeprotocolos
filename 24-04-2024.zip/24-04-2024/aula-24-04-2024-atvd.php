<?php

$num1 = 25; $num2 = 100;
$resultadosoma = $num1 + $num2;
$resultadomultiplicacao = $num1 * $num2;
$resultadosubtracao = $num1 - $num2;
$resultadodivisão = $num1 / $num2;

echo " <br> Resultado da soma de " .$num1. " + " .$num2. " = " .$resultadosoma;
echo " <br> Resultado da multiplicação de " .$num1. " x " .$num2. " = " .$resultadomultiplicacao ;
echo " <br> Resultado da subtração de " .$num1. " - " .$num2. " = " .$resultadosubtracao;
echo " <br> Resultado da divisão de " .$num1. " / " .$num2. " = " .$resultadodivisão;

?>