<?php

for ($i = 0; $i <= 10; $i++) {
    $antecessor = $i - 1;
    $sucessor = $i + 1;

    echo " Número: " . $i . ", Antecessor : " . $antecessor . ", Sucessor: " . $sucessor . "<br>";
}

?>
