<?php

$numero = 7;

$dobro = $numero * 2;

echo "Número: " . $numero . "<br>";
echo "Dobro: " . $dobro;

?>
