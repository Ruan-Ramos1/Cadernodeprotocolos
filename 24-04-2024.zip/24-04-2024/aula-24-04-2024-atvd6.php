<?php

$numero = 10;

$acrescido = $numero + ($numero * 0.47);

echo " Número: " . $numero . "<br>";
echo " Acrescido de 47%: " . $acrescido;

?>
