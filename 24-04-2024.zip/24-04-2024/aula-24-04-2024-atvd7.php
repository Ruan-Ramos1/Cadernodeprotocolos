<?php

$numero = 100;

$subtraido = $numero - ($numero * 0.26);

echo "Número: " . $numero . "<br>";
echo "Subtraído de 26%: " . $subtraido;

?>
