<?php

$numero1 = 5;
$numero2 = 8;

$soma_quadrado = ($numero1 + $numero2) ** 2;

$resultado = $soma_quadrado * 1.14;

echo "A soma dos números ao quadrado acrescida de 14% é: " . $resultado;

?>
